#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

// Function to initialize IPC (create shared memory), accepts memory name and memory size as parameters
// Returns 0 on success, non-zero on failure
int initializeIPC(const char* sharedMemoryName, size_t sharedMemorySize, HANDLE* hMapFile, char** pBuf)
{
    // Create a file mapping (shared memory)
    *hMapFile = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // Use paging file
        NULL,                    // Default security attributes
        PAGE_READWRITE,          // Read/write access
        0,                       // Maximum object size (high-order DWORD)
        sharedMemorySize,        // Maximum object size (low-order DWORD)
        sharedMemoryName);       // Name of the shared memory object

    if (*hMapFile == NULL)
    {
        return 1;  // Error creating file mapping
    }

    // Map a view of the file into the address space of the calling process
    *pBuf = (char*) MapViewOfFile(
        *hMapFile,               // Handle to the map object
        FILE_MAP_ALL_ACCESS,     // Read/write permission
        0,
        0,
        sharedMemorySize);

    if (*pBuf == NULL)
    {
        CloseHandle(*hMapFile);
        return 2;  // Error mapping view of file
    }

    return 0;  // Success
}

// Function to write a string message and a double array to shared memory
void writeIPC(char* pBuf, const char* message, const double* dataArray, size_t arraySize)
{
    // Copy the string message to the beginning of the shared memory
    size_t messageLength = strlen(message) + 1;  // +1 for null-termination
    memcpy(pBuf, message, messageLength);

    // Copy the double array to the shared memory right after the string
    memcpy(pBuf + messageLength, dataArray, arraySize * sizeof(double));
}

// Function to close IPC (cleanup)
void closeIPC(HANDLE hMapFile, char* pBuf)
{
    if (pBuf != NULL)
    {
        UnmapViewOfFile(pBuf);  // Unmap the memory
    }

    if (hMapFile != NULL)
    {
        CloseHandle(hMapFile);  // Close the file mapping
    }
}

int main()
{
    const char* sharedMemoryName = "Local\\MySharedMemory";  // Example shared memory name
    size_t sharedMemorySize = 4096 + sizeof(double) * 10000; // Memory size for string + 10000 doubles
    HANDLE hMapFile = NULL;                                  // Handle to shared memory
    char* pBuf = NULL;                                       // Pointer to shared memory buffer
    int counter = 0;

    // Step 1: Initialize IPC with memory name and size
    int initResult = initializeIPC(sharedMemoryName, sharedMemorySize, &hMapFile, &pBuf);
    if (initResult != 0)
    {
        return initResult;  // Exit if initialization fails
    }

    // Initialize a 10,000-element double array with dummy values
    double dataArray[10000];
    for (int i = 0; i < 10000; i++)
    {
        dataArray[i] = (double)(i + 1);  // Dummy data: values from 1.0 to 10000.0
    }

    // Step 2: Continuously write data to IPC
    while (1) 
    {
        SYSTEMTIME st;
        char message[256];  // Buffer for the message string

        // Get current system time
        GetSystemTime(&st);

        // Format the message with a millisecond timestamp
        sprintf(message, "Message %d - Time: %02d:%02d:%02d.%03d",
                counter,
                st.wHour,
                st.wMinute,
                st.wSecond,
                st.wMilliseconds);

        // Write the message and the double array to shared memory
        writeIPC(pBuf, message, dataArray, 10000);

        // Print the data written to shared memory (for testing purposes)
        printf("Data written to shared memory: %s\n", message);

        counter++;  // Increment message counter

        // Sleep for 1 millisecond before writing the next message
        Sleep(20);
    }

    // Step 3: Close IPC (cleanup) - never reached due to infinite loop
    closeIPC(hMapFile, pBuf);

    return 0;
}
