#include <windows.h>
#include <stdio.h>
#include <string.h>  // For strncpy

// Function to initialize IPC (open shared memory), accepts memory name, memory size, handle, and buffer pointer
// Returns 0 on success, non-zero on failure
int initIPC(const char* sharedMemoryName, size_t memSize, HANDLE* hMapFile, char** pBuf)
{
    // Open an existing file mapping object (shared memory)
    *hMapFile = OpenFileMapping(
        FILE_MAP_ALL_ACCESS,   // Read/write access
        FALSE,                 // Do not inherit the name
        sharedMemoryName);     // Name of the shared memory object

    if (*hMapFile == NULL)
    {
        return 1;  // Return error code if file mapping failed
    }

    // Map a view of the file into the address space of the calling process
    *pBuf = (char*) MapViewOfFile(
        *hMapFile,             // Handle to the map object
        FILE_MAP_ALL_ACCESS,   // Read/write permission
        0,
        0,
        memSize);              // Size of the shared memory

    if (*pBuf == NULL)
    {
        CloseHandle(*hMapFile);
        return 2;  // Return error code if mapping view failed
    }

    return 0;  // Success
}

// Function to close IPC (cleanup), accepts shared memory handle and buffer pointer
void closeIPC(HANDLE hMapFile, char* pBuf)
{
    if (pBuf != NULL)
    {
        UnmapViewOfFile(pBuf);  // Unmap the memory
    }

    if (hMapFile != NULL)
    {
        CloseHandle(hMapFile);  // Close the file mapping
    }
}

// Function to read and return the string and double array from shared memory
// This function checks if the data is the same as the last read, and if so, returns -99
int readIPC(char* pBuf, char* message, size_t messageSize, double** dataArray, size_t* arraySize, char* lastMessage)
{
    // Check if the data in shared memory is the same as the last read message
    if (strncmp(lastMessage, pBuf, messageSize) == 0) {
        return -99;  // Data is the same, return -99
    }

    // Copy the string message from shared memory
    strncpy(message, pBuf, messageSize - 1);
    message[messageSize - 1] = '\0';  // Ensure null termination

    // Store the current message as the last message
    strncpy(lastMessage, message, messageSize);

    // Point to the double array (stored after the message)
    *dataArray = (double*)(pBuf + strlen(message) + 1);

    // Set the array size (assuming 10000 elements)
    *arraySize = 10000;

    return 0;  // Success
}

int main()
{
    const char* sharedMemoryName = "Local\\MySharedMemory";  // Example shared memory name
    size_t memSize = 4096 + sizeof(double) * 10000;          // Shared memory size for string + 10000 doubles
    HANDLE hMapFile = NULL;                                  // Local handle to shared memory
    char* pBuf = NULL;                                       // Local pointer to shared memory buffer
    char message[256];                                       // Buffer for the string message
    double* dataArray = NULL;                                // Pointer to the double array
    size_t arraySize = 0;                                    // Size of the double array
    char lastMessage[256] = {0};                             // Store the last read message for comparison

    // Step 1: Initialize IPC with a memory name and size
    int initStatus = initIPC(sharedMemoryName, memSize, &hMapFile, &pBuf);
    if (initStatus != 0)
    {
        return initStatus;  // Exit if initialization fails
    }

    // Step 2: Continuously read data from IPC in a loop
    while (1) 
    {
        // Read both the string message and the double array from shared memory
        int result = readIPC(pBuf, message, sizeof(message), &dataArray, &arraySize, lastMessage);

        // If the data is unchanged, skip printing
        if (result == -99)
        {
            Sleep(0);  // Sleep briefly to avoid high CPU usage
            continue;    // Skip to the next iteration
        }

        // Get the current system time
        SYSTEMTIME currentTime;
        GetSystemTime(&currentTime);

        // Print the message
        printf("Message: %s", message);

        // Print the current system time
        printf("Current time: %02d:%02d:%02d.%03d", 
               currentTime.wHour, 
               currentTime.wMinute, 
               currentTime.wSecond, 
               currentTime.wMilliseconds);

        // Print the first and last element of the double array
        if (arraySize > 0) 
        {
            printf(" First %f", dataArray[0]);
            printf(" Last %f", dataArray[arraySize - 1]);
        }

        printf("\n");

        Sleep(0);  // Sleep briefly to avoid high CPU usage
    }

    // Step 3: Cleanup (this will never be reached in the current infinite loop)
    closeIPC(hMapFile, pBuf);

    return 0;
}
